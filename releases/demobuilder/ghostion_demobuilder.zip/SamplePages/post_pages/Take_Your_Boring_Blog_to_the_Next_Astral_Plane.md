![Image](http://ghostdemo.axiantheme.com/ghostion/demo/img01.jpg)

8-bit four loko organic, wolf tofu pitchfork gluten-free quinoa sustainable locavore helvetica messenger bag banksy thundercats. Williamsburg sartorial chambray fixie, raw denim freegan marfa cliche hoodie yr blog seitan. Trust fund lomo messenger bag, cosby sweater brooklyn mcsweeney's salvia 8-bit ethical yr. Mustache cardigan echo park sustainable, food truck Austin keffiyeh keytar mixtape art party four loko gentrify freegan american apparel.

Ghost is an Open Source application which allows you to write and publish your own blog, giving you the tools to make it easy and even fun to do. It's simple, elegant, and designed so that you can spend less time making your blog work and more time blogging.

Seitan irony banh mi, vegan stumptown aesthetic keffiyeh wolf Austin cardigan before they sold out banksy portland wes anderson synth. Retro echo park four loko, homo blog carles mcsweeney's vice lo-fi. Ethical salvia butcher sustainable blog fixie, dreamcatcher pitchfork retro hoodie marfa Austin you probably haven't heard of them yr.

Terry richardson high life craft beer, seitan four loko salvia vegan iphone echo park raw denim brunch cliche viral irony williamsburg. Sustainable cosby sweater high life brooklyn. Seitan raw denim pitchfork four loko vinyl messenger bag tofu brooklyn banh mi, gentrify tumblr.

Brunch cliche 8-bit williamsburg dreamcatcher, hoodie art party. Biodiesel gluten-free twee mlkshk. Before they sold out whatever hoodie biodiesel 3 wolf moon, keffiyeh wolf twee lo-fi. Bicycle rights food truck scenester, leggings gluten-free master cleanse freegan lomo brunch fanny pack biodiesel squid.